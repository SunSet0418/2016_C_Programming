struct people {
	char name[50];
	int height;
	double weight;
};