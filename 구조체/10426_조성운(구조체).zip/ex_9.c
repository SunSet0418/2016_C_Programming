#include <stdio.h>
#include <string.h>
#include "9.h"
struct people tmpstruct;
#define swap(a,b){tmpstruct = a; a = b; b = tmpstruct;}
int main() {
	struct people score[4] = {
		{ 1,"�輱��",89,75,70,0,'A' },
		{ 2,"������",67,56,80,0,'B' },
		{ 3,"������",90,100,89,0,'C' },
		{ 4,"������",75,86,96,0,'D' }
	};
	int i, j;
	for (i = 0; i < 4; i++) {
		printf("%d\t", score[i].num);
		printf("%s\t", score[i].name);
		printf("%d\t", score[i].pro);
		printf("%d\t", score[i].os);
		printf("%d\t", score[i].web);
		printf("%.2lf\t", score[i].ave);
		printf("%c\n", score[i].grade);
	}
	double max;
	printf("��ȣ\t�̸�\t����\tOS\tWEB\tAVG\tGrade\n");
	for (i = 0; i < 4; i++) {
		score[i].ave = (double)(score[i].pro + score[i].os + score[i].web) / 3;
		for (j = 50; j <= 90; j += 10) {
			if (score[i].ave >= j) score[i].grade--;
		}
	}

	for (i = 0; i < 4; i++) {
		max = score[i].ave;

		for (j = i + 1; j < 4; j++)
			max = (max > score[j].ave) ? max : score[j].ave;

		for (j = 0; j < 4; j++) {
			if (max == score[j].ave)
				break;
		}
		swap(score[i], score[j]);
	}

	for (i = 0; i < 4; i++) {
		printf("%d\t", score[i].num);
		printf("%s\t", score[i].name);
		printf("%d\t", score[i].pro);
		printf("%d\t", score[i].os);
		printf("%d\t", score[i].web);
		printf("%.2f\t", score[i].ave);
		printf("%c\n", score[i].grade);
	}
}