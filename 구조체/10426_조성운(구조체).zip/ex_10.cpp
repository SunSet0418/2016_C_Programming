#include<stdio.h>
#include<string.h>
#include"sort.h"
struct people ex[5];
struct people tmp;
#define Swap(a,b){tmp=a;a=b;b=tmp;}
int sort() {
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++){
			if (ex[j].height > ex[j + 1].height) {
				Swap(ex[j], ex[j + 1]);
			}
		}
	}
	printf("�̸�\tŰ\t������\n");
	for (int i = 0; i < 5; i++) {
		printf("%s\t", ex[i].name);
		printf("%d\t", ex[i].height);
		printf("%.2lf\n", ex[i].weight);
	}
	return 0;
}
int main() {
	for (int i = 0; i < 5; i++) {
		printf("%d�� �̸� : ", i + 1);
		scanf("%s", ex[i].name);
		printf("%d�� Ű : ", i + 1);
		scanf("%d", &ex[i].height);
		printf("%d�� ������ : ", i + 1);
		scanf("%.2lf", &ex[i].weight);
	}
	printf("�̸�\tŰ\t������\n");
	for (int i = 0; i < 5; i++) {
		printf("%s\t", ex[i].name);
		printf("%d\t", ex[i].height);
		printf("%.2lf\n", ex[i].weight);
	}
	sort();
}