struct people {
	char name[20];
	int num;
	int pro;
	int os;
	int web;
	double ave;
	char grade;
};